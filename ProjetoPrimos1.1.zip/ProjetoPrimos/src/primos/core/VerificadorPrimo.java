package primos.core;

 //Classe responsável por verificar se um número é primo.
public class VerificadorPrimo {
    public static boolean ehPrimo(int numero) {
        if (numero <= 1) {
            return false; // Números menores ou iguais a 1 não são primos
        }
        for (int i = 2; i * i <= numero; i++) {
            if (numero % i == 0) {
                return false; // Se for divisível por algum número, não é primo
            }
        }
        return true; // Se não foi divisível por nenhum número, é primo
    }
}