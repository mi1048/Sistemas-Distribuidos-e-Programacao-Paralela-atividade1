package primos.app;

import primos.core.BuscadorPrimosSequencial;
import primos.core.BuscadorPrimosParalelo;
import primos.io.ManipuladorArquivo;
import org.knowm.xchart.*;
import java.util.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Caminhos dos arquivos
        String arquivoEntrada = "./entrada.txt";
        String arquivoSaida = "./saida.txt";

        // Implementação sequencial
        long inicioTempo = System.currentTimeMillis();
        List<Integer> primosSequencial = BuscadorPrimosSequencial.encontrarPrimos(arquivoEntrada);
        ManipuladorArquivo.escreverPrimosNoArquivo(arquivoSaida, primosSequencial);
        long tempoSequencial = System.currentTimeMillis() - inicioTempo;
        System.out.println("Tempo sequencial: " + tempoSequencial + " ms");

        // Lista para armazenar tempos paralelos e speedup
        int[] numThreads = {
            2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 
            27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 
            49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 
            71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 
            93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 
            112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 
            130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 
            148, 149, 150
        }; // Threads de 2 a 300
        List<Double> speedupValores = new ArrayList<>();
        List<Integer> threadsList = new ArrayList<>();
        List<Long> temposParalelo = new ArrayList<>();
        List<Integer> threadsParalelo = new ArrayList<>();

        for (int threads : numThreads) {
            inicioTempo = System.currentTimeMillis();
            List<Integer> primosParalelo = BuscadorPrimosParalelo.encontrarPrimos(arquivoEntrada, threads);
            ManipuladorArquivo.escreverPrimosNoArquivo(arquivoSaida, primosParalelo);
            long tempoParalelo = System.currentTimeMillis() - inicioTempo;
            System.out.println("Tempo paralelo (" + threads + " threads): " + tempoParalelo + " ms");

            // Armazena os tempos paralelos
            temposParalelo.add(tempoParalelo);
            threadsParalelo.add(threads);

            // Calcula speedup
            double speedup = (double) tempoSequencial / tempoParalelo;
            speedupValores.add(speedup);
            threadsList.add(threads);
        }

        // Gerar gráficos
        mostrarGraficoTempoReal(temposParalelo, threadsParalelo, tempoSequencial);
        mostrarGraficoSpeedup(threadsList, speedupValores);
    }

    // Gráfico de tempos de execução
    private static void mostrarGraficoTempoReal(List<Long> temposParalelo, List<Integer> threads, long tempoSequencial) {
        XYChart chart = new XYChartBuilder().width(600).height(400).title("Tempo Real de Execução vs Threads")
                .xAxisTitle("Número de Threads").yAxisTitle("Tempo de Execução (ms)").build();

        // Adiciona os dados de tempo sequencial
        List<Integer> threadsSequencial = Collections.singletonList(0);  // Para representar o tempo sequencial
        List<Long> temposSequencial = Collections.singletonList(tempoSequencial);
        chart.addSeries("Tempo Sequencial", threadsSequencial, temposSequencial);

        // Adiciona os dados de tempo paralelo
        chart.addSeries("Tempo Paralelo", threads, temposParalelo);

        new SwingWrapper<>(chart).displayChart();
    }

    // Gráfico de Speedup
    private static void mostrarGraficoSpeedup(List<Integer> threads, List<Double> speedupValores) {
        XYChart chart = new XYChartBuilder().width(600).height(400).title("Speedup vs Threads")
                .xAxisTitle("Número de Threads").yAxisTitle("Speedup").build();

        chart.addSeries("Speedup", threads, speedupValores);

        new SwingWrapper<>(chart).displayChart();
    }
}
