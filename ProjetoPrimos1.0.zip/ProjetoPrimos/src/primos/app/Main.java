package primos.app;

import primos.core.BuscadorPrimosSequencial;
import primos.core.BuscadorPrimosParalelo;
import primos.io.ManipuladorArquivo;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Caminhos dos arquivos (relativos à raiz do projeto)
        String arquivoEntrada = "./entrada.txt"; // Arquivo de entrada
        String arquivoSaida = "./saida.txt";   // Arquivo de saída

        // Implementação sequencial
        long inicioTempo = System.currentTimeMillis();
        List<Integer> primosSequencial = BuscadorPrimosSequencial.encontrarPrimos(arquivoEntrada);
        ManipuladorArquivo.escreverPrimosNoArquivo(arquivoSaida, primosSequencial);
        long fimTempo = System.currentTimeMillis();
        System.out.println("Tempo sequencial: " + (fimTempo - inicioTempo) + " ms");

        // Implementação paralela com 5 threads
        inicioTempo = System.currentTimeMillis();
        List<Integer> primosParalelo5 = BuscadorPrimosParalelo.encontrarPrimos(arquivoEntrada, 5);
        ManipuladorArquivo.escreverPrimosNoArquivo(arquivoSaida, primosParalelo5);
        fimTempo = System.currentTimeMillis();
        System.out.println("Tempo paralelo (5 threads): " + (fimTempo - inicioTempo) + " ms");

        // Implementação paralela com 10 threads
        inicioTempo = System.currentTimeMillis();
        List<Integer> primosParalelo10 = BuscadorPrimosParalelo.encontrarPrimos(arquivoEntrada, 10);
        ManipuladorArquivo.escreverPrimosNoArquivo(arquivoSaida, primosParalelo10);
        fimTempo = System.currentTimeMillis();
        System.out.println("Tempo paralelo (10 threads): " + (fimTempo - inicioTempo) + " ms");
    }
}