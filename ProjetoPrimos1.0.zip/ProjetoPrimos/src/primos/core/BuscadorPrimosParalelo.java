package primos.core;

import primos.io.ManipuladorArquivo;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

//Classe responsável por encontrar números primos de forma paralela usando múltiplas threads.
public class BuscadorPrimosParalelo {
    public static List<Integer> encontrarPrimos(String arquivoEntrada, int numThreads) {
        List<Integer> primos = new ArrayList<>();
        List<Integer> numeros = ManipuladorArquivo.lerNumerosDoArquivo(arquivoEntrada); // Lê os números do arquivo
        ExecutorService executor = Executors.newFixedThreadPool(numThreads); // Cria um pool de threads
        List<Future<Boolean>> futures = new ArrayList<>();

        // Submete tarefas para verificar se cada número é primo
        for (int numero : numeros) {
            Callable<Boolean> tarefa = () -> VerificadorPrimo.ehPrimo(numero);
            futures.add(executor.submit(tarefa));
        }

        // Coleta os resultados das tarefas
        for (int i = 0; i < numeros.size(); i++) {
            try {
                if (futures.get(i).get()) { // Se o número for primo
                    primos.add(numeros.get(i)); // Adiciona à lista de primos
                }
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace(); // Trata exceções durante a execução das threads
            }
        }

        executor.shutdown(); // Encerra o pool de threads
        return primos; // Retorna a lista de números primos
    }
}