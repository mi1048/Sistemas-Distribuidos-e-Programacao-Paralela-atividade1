package primos.core;

import primos.io.ManipuladorArquivo;
import java.util.ArrayList;
import java.util.List;

 //Classe responsável por encontrar números primos de forma sequencial.
public class BuscadorPrimosSequencial {
    public static List<Integer> encontrarPrimos(String arquivoEntrada) {
        List<Integer> primos = new ArrayList<>();
        List<Integer> numeros = ManipuladorArquivo.lerNumerosDoArquivo(arquivoEntrada); // Lê os números do arquivo

        for (int numero : numeros) {
            if (VerificadorPrimo.ehPrimo(numero)) { // Verifica se o número é primo
                primos.add(numero); // Adiciona à lista de primos
            }
        }

        return primos; // Retorna a lista de números primos
    }
}