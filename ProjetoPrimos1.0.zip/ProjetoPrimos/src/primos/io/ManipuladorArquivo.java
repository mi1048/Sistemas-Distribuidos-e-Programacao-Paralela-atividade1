package primos.io;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

 //Classe responsável por manipular arquivos (leitura e escrita).
public class ManipuladorArquivo {

     //Lê números de um arquivo de entrada.
    public static List<Integer> lerNumerosDoArquivo(String arquivoEntrada) {
        List<Integer> numeros = new ArrayList<>();
        try (BufferedReader leitor = new BufferedReader(new FileReader(arquivoEntrada))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                numeros.add(Integer.parseInt(linha.trim())); // Converte a linha para número e adiciona à lista
            }
        } catch (IOException e) {
            e.printStackTrace(); // Trata erros de leitura do arquivo
        }
        return numeros; // Retorna a lista de números
    }

     //Escreve números primos em um arquivo de saída.
    public static void escreverPrimosNoArquivo(String arquivoSaida, List<Integer> primos) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(arquivoSaida))) {
            for (int primo : primos) {
                escritor.write(primo + "\n"); // Escreve cada número primo no arquivo
            }
        } catch (IOException e) {
            e.printStackTrace(); // Trata erros de escrita no arquivo
        }
    }
}